/*
 * Copyright 2024 jrosclient project
 * 
 * Website: https://github.com/lambdaprime/jros1client
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
import id.jros1client.JRos1ClientConfiguration;
import id.jros1client.JRos1ClientFactory;
import id.jrosclient.TopicSubscriber;
import id.jrosmessages.std_msgs.StringMessage;

/** Subscribes to ROS topic */
public class SubscriberApp {

    public static void main(String[] args) throws Exception {
        var config = new JRos1ClientConfiguration();
        // host address where jrosclient is running and to which other ROS nodes
        // will communicate
        config.setHostAddress("localhost");
        // specify URL of the master node
        var client = new JRos1ClientFactory().createClient("http://localhost:11311/");
        var topicName = "/helloRos";
        // register a new subscriber
        client.subscribe(
                new TopicSubscriber<>(StringMessage.class, topicName) {
                    @Override
                    public void onNext(StringMessage item) {
                        System.out.println(item);
                        // request next message
                        getSubscription().get().request(1);
                    }
                });

        // usually we need to close client once we are done
        // but here we keep it open so that subscriber will keep
        // printing messages indefinitely
    }
}
