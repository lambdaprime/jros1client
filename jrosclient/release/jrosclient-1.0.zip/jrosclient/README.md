**jrosclient** - Java module which allows to interact with ROS (Robotic Operation System).

# Download

You can download **jrosclient** from <https://github.com/lambdaprime/jrosclient/releases>

# Documentation

Documentation is available here <http://portal2.atwebpages.com/jrosclient>
```
# Contributors

lambdaprime <intid@protonmail.com>
